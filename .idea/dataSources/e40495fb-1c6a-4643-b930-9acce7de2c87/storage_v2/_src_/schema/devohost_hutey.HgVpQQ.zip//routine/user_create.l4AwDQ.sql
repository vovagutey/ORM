create
    definer = devohost_hutey@`%` procedure user_create(IN user_login varchar(30), IN user_pass varchar(30),
                                                       IN user_email varbinary(50))
BEGIN
    INSERT into users (login, password, email) values (user_login,user_pass,user_email);
end;

