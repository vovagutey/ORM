create
    definer = devohost_hutey@`%` procedure user_update(IN userId int, IN user_login varchar(30),
                                                       IN user_pass varchar(30), IN user_email varbinary(50),
                                                       IN user_phone varchar(15))
begin
    UPDATE users set login = user_login,
                     password = user_pass,
                     email = user_email,
                     phone = user_phone
    where user_id = userId;

end;

