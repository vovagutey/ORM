create
    definer = devohost_hutey@`%` procedure get_created_user(IN user_login int)
begin
    SELECT * from users where login = user_login;

end;

