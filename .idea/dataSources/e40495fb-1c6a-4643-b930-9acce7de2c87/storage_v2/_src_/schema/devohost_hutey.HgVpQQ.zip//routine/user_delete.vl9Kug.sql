create
    definer = devohost_hutey@`%` procedure user_delete(IN userId int)
begin
    DELETE from users where user_id = userId;

end;

