create
    definer = devohost_hutey@`%` procedure full_user_create(IN user_login varchar(30), IN user_pass varchar(30),
                                                            IN user_email varbinary(50), IN user_phone varchar(15))
BEGIN
    INSERT into users (login, password, email, phone) values (user_login,user_pass,user_email, user_phone);
end;

